package paint.board;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.util.Stack;

import static paint.board.ArcStatus.*;
import static paint.board.BasicTools.*;

public class CanvasPanelListener extends JPanel implements MouseListener, MouseMotionListener {

    public static boolean isInCanvas = false;

    /**
     * x1, y1为鼠标按下时的位置
     * x2, y2为鼠标移动过程中的实时位置
     */
    private int x1, x2, y1, y2;
    private boolean dragged = false;
    private Color currentColor;
    private Color lastColor;
    private int grouped;
    private boolean isTransparent;
    private BasicStroke stroke = new BasicStroke(2);
    /**
     * 显示的图像
     */
    private Stack<Shape> shapes;
    /**
     * 实际的图像
     */
    private Stack<Shape> shapesALL;
    private Stack<Shape> removed;
    private Stack<Shape> preview;
    private BufferedImage canvas;
    private Graphics2D graphics2D;
    private TextDialog textDialog;
    private BasicTools actTool;
    private ArcStatus drawStatus = NOT_DRAWING;
    private ArcStatus direction = NO_DIRECTION;
    private Dimension center, startPoint;
    private int radius;
    private Vec3 benchmark;
    private Rectangle rectangle;

    /**
     * 当前被选择的形状
     */
    private Shape selectedShape;
    /**
     * 上一个被选择的形状
     */
    private Shape lastSelectedShape;
    /**
     * 当前被复制的形状
     */
    private Shape copiedShape;
    private Stack<String> tags;

    public CanvasPanelListener() {
        setSize(800, 600);
        Dimension d = new Dimension(800, 600);
        setMinimumSize(d);
        setMaximumSize(d);
        setBorder(BorderFactory.createLineBorder(Color.lightGray));
        setBackground(Color.white);

        addMouseListener(this);
        addMouseMotionListener(this);
        requestFocus();
        actTool = BasicTools.NULL;
        //System.out.println("create");
        currentColor = Color.BLACK;
        lastColor = Color.WHITE;
        textDialog = new TextDialog(Main.mainWindow);

        this.shapes = new Stack<>();
        this.shapesALL = new Stack<>();
        this.tags = new Stack<>();
        this.removed = new Stack<>();
        this.grouped = 1;
        this.preview = new Stack<>();
        this.isTransparent = true;
    }

    public CanvasPanelListener(int x, int y) {
        setSize(x, y);
        Dimension d = new Dimension(x, y);
        setMaximumSize(d);
        setMinimumSize(d);
        setBorder(BorderFactory.createLineBorder(Color.lightGray));
        setBackground(Color.white);

        addMouseListener(this);
        addMouseMotionListener(this);
        requestFocus();
        actTool = PENCIL;
        currentColor = Color.BLACK;
        lastColor = Color.WHITE;
        textDialog = new TextDialog(Main.mainWindow);
        this.shapes = new Stack<>();
        this.shapesALL = new Stack<>();
        this.tags = new Stack<>();
        this.removed = new Stack<>();
        this.preview = new Stack<>();
        this.grouped = 1;
        this.isTransparent = true;
    }

    public void changeCanvasPanelSize(int w, int h) {
        shapes.clear();
        removed.clear();
        preview.clear();

        Dimension d = new Dimension(w, h);
        setSize(d);
        setMaximumSize(d);
        setMinimumSize(d);
        repaint();
        Main.mainWindow.setCanvasSizeLabel(w, h);
    }

    public void setBICanvas(Dimension d) {
        canvas = new BufferedImage(d.width, d.height, BufferedImage.TYPE_INT_ARGB);
        graphics2D = canvas.createGraphics();
        clear(d.width, d.height);
    }

    public void paintComponent(Graphics g) {
        //System.out.println(activeTool.toString() + "pc");
        Dimension dimension = Main.mainWindow.getCanvas().getSize();
        if (canvas == null) {
            canvas = new BufferedImage(dimension.width, dimension.height, BufferedImage.TYPE_INT_ARGB);
            graphics2D = canvas.createGraphics();
            graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            clear();
        }
        g.drawImage(canvas, 0, 0, null);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        for (Shape s : shapes) {
            g2.setColor(s.getColor());
            g2.setStroke(s.getStroke());

            if (s.getShape() == LINE) {
                g2.drawLine(s.getX1(), s.getY1(), s.getX2(), s.getY2());
            } else if (s.getShape() == RECTANGLE) {
                g2.drawRect(s.getX1(), s.getY1(), s.getWidth(), s.getHeight());
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillRect(s.getX1(), s.getY1(), s.getWidth(), s.getHeight());
                }
            } else if (s.getShape() == ELLIPTICAL) {
                g2.drawOval(s.getX1(), s.getY1(), s.getWidth(), s.getHeight());
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillOval(s.getX1(), s.getY1(), s.getWidth(), s.getHeight());
                }
            } else if (s.getShape() == COMPASS) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 8);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 8);
                }
            } else if (s.getShape() == PENTAGON) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 5);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 5);
                }
            } else if (s.getShape() == PENTAGRAM) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 10);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 10);
                }
            } else if (s.getShape() == HEXAGON) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 6);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 6);
                }
            } else if (s.getShape() == TRIANGLE) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 3);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 3);
                }
            } else if (s.getShape() == ARC) {
                g2.drawArc(s.getRectangle().x, s.getRectangle().y, s.getRectangle().width, s.getRectangle().height,
                        s.getStartAngle(), s.getDrawAngle());
                if (!s.transparent) {
                    g2.fillArc(s.getRectangle().x, s.getRectangle().y, s.getRectangle().width, s.getRectangle().height,
                            s.getStartAngle(), s.getDrawAngle());
                }
            } else if (s.getShape() == TEXT) {
                g2.setFont(s.getFont());
                g2.drawString(s.getMessage(), s.getX1(), s.getY1());
            }
        }
        if (preview.size() > 0) {
            Shape s = preview.peek();
            g2.setColor(s.getColor());
            g2.setStroke(s.getStroke());
            if (s.getShape() == LINE) {
                g2.drawLine(s.getX1(), s.getY1(), s.getX2(), s.getY2());
            } else if (s.getShape() == RECTANGLE) {
                g2.drawRect(s.getX1(), s.getY1(), s.getWidth(), s.getHeight());
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillRect(s.getX1(), s.getY1(), s.getWidth(), s.getHeight());
                }
            } else if (s.getShape() == ELLIPTICAL) {
                g2.drawOval(s.getX1(), s.getY1(), s.getWidth(), s.getHeight());
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillOval(s.getX1(), s.getY1(), s.getWidth(), s.getHeight());
                }
            } else if (s.getShape() == COMPASS) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 8);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 8);
                }
            } else if (s.getShape() == PENTAGON) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 5);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 5);
                }
            } else if (s.getShape() == PENTAGRAM) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 10);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 10);
                }
            } else if (s.getShape() == HEXAGON) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 6);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 6);
                }
            } else if (s.getShape() == TRIANGLE) {
                g2.drawPolygon(s.getPosX(), s.getPosY(), 3);
                if (!s.transparent) {
                    g2.setColor(s.getFillColor());
                    g2.fillPolygon(s.getPosX(), s.getPosY(), 3);
                }
            } else if (s.getShape() == ARC) {
                var rec = s.getRectangle();
                g2.drawArc(rec.x, rec.y, rec.width, rec.height, s.getStartAngle(), s.getDrawAngle());
                if (!s.transparent) {
                    g2.fillArc(rec.x, rec.y, rec.width, rec.height,
                            s.getStartAngle(), s.getDrawAngle());
                }
            }
        }
    }

    public void clear() {
        Dimension dimension = Main.mainWindow.getCanvas().getSize();
        graphics2D.setPaint(Color.white);
        graphics2D.fillRect(0, 0, dimension.width, dimension.height);
        shapes.removeAllElements();
        removed.removeAllElements();
        Main.mainWindow.getCanvas().repaint();
        graphics2D.setColor(currentColor);
    }

    public void clear(int x, int y) {
        graphics2D.setPaint(Color.white);
        graphics2D.fillRect(0, 0, x, y);
        shapes.removeAllElements();
        removed.removeAllElements();
        Main.mainWindow.getCanvas().repaint();
        graphics2D.setColor(currentColor);
    }

    public void setTool(BasicTools tool) {
        if(tool != ALIGNMENT){
            for (var shape : shapes){
                shape.setIsSelected(0);
            }
        }
        this.actTool = tool;
    }

    public void setInkPanel(int w, int h) {
        // -----** 存疑 **-----
        // 这里必须用argb吗？
        canvas = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        graphics2D = canvas.createGraphics();
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        this.setSize(w - 3, h - 3);
        this.setPreferredSize(new Dimension(w - 3, h - 3));
        clear();
    }

    public void setImage(BufferedImage image) {
        graphics2D.dispose();
        this.setInkPanel(image.getWidth(), image.getHeight());
        canvas = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_ARGB);
        graphics2D = canvas.createGraphics();
        graphics2D.drawImage(image, 0, 0, null);
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
    }

    public void setColor(Color color) {
        lastColor = currentColor;
        currentColor = color;
        graphics2D.setColor(color);
    }

    public void setThickness(float f) {
        stroke = new BasicStroke(f);
        graphics2D.setStroke(stroke);
    }

    public void setTransparent(Boolean b) {
        this.isTransparent = b;
    }

    public Color getCurrentColor() {
        return currentColor;
    }

    public int getDistance(Dimension d1, Dimension d2) {
        return (int) Math.sqrt((d1.height - d2.height) * (d1.height - d2.height) + (d1.width - d2.width) * (d1.width - d2.width));
    }

    // todo: shape fill

    public void undo() {
        if (shapes.size() == 0) {
            return;
        }

        Shape last = shapes.pop();
        removed.push(last);

        if (last.group == 0) {
            repaint();
        } else {
            while (!shapes.isEmpty() && shapes.peek().group == last.group) {
                removed.push(shapes.pop());
                repaint();
            }
        }
    }

    public void redo() {
        if (removed.size() > 0 && removed.peek().group == 0) {
            shapes.push(removed.pop());
            repaint();
        } else if (removed.size() > 0 && removed.peek().group != 0) {
            Shape last = removed.pop();
            shapes.push(last);
            while (!removed.isEmpty() && removed.peek().group == last.group) {
                shapes.push(removed.pop());
                repaint();
            }
        }
    }

    public void addLabel() {
        JDialog tagFrame = new JDialog(Main.mainWindow,"选择标签",true);
        tagFrame.setBounds(750,450,365,75);
        tagFrame.setLayout((new FlowLayout(10,10,FlowLayout.CENTER)));
        JComboBox<String> comboBox = new JComboBox<>(tags);
        comboBox.setPreferredSize(new Dimension(170,25));
        comboBox.setEditable(false);
        JButton newButton = getNewButton(tagFrame);
        JButton OKButton = new JButton("确定");
        OKButton.addActionListener(b -> {
            String tag = (String) comboBox.getSelectedItem();
            if(tag == null){
                //System.out.println("null");
                return;
            }
            selectedShape.addTag(tag);
            tagFrame.setVisible(false);
        });
        tagFrame.add(comboBox);
        tagFrame.add(OKButton);
        tagFrame.add(newButton);
        tagFrame.setVisible(true);

    }

    private JButton getNewButton(JDialog tagFrame) {
        JTextField textField = new JTextField();
        JDialog newFrame = new JDialog(tagFrame,"新建标签",true);
        textField.setPreferredSize(new Dimension(170,25));
        JButton newButton = new JButton("新建标签");
        JButton creatButton = new JButton("创建");
        newButton.addActionListener(b -> {
            newFrame.setBounds(760,460,365,75);
            newFrame.setLayout((new FlowLayout(10,10,FlowLayout.CENTER)));
            newFrame.add(textField);
            newFrame.add(creatButton);
            newFrame.setVisible(true);
        });
        creatButton.addActionListener(b -> {
            String newTag = textField.getText();
            for(String s : tags){
                if(s.equals(newTag)){
                    newFrame.setVisible(false);
                    return;
                }
            }
            tags.add(newTag);
            newFrame.setVisible(false);
        });
        return newButton;
    }

    public void showByLabel() {
        for(Shape shape :shapes){
            if(!shapesALL.contains(shape)){
                shapesALL.add(shape);
            }
        }
        JDialog tagFrame = new JDialog(Main.mainWindow,"选择标签",true);
        tagFrame.setBounds(750,450,365,75);
        tagFrame.setLayout((new FlowLayout(10,10,FlowLayout.CENTER)));
        JComboBox<String> comboBox2 = new JComboBox<>(tags);
        comboBox2.addItem("显示全部");
        comboBox2.setPreferredSize(new Dimension(170,25));
        comboBox2.setEditable(false);
        JButton OKButton = getOkButton(comboBox2, tagFrame);
        tagFrame.add(comboBox2);
        tagFrame.add(OKButton);
        tagFrame.setVisible(true);
    }

    private JButton getOkButton(JComboBox<String> comboBox2, JDialog tagFrame) {
        JButton OKButton = new JButton("确定");
        OKButton.addActionListener(b -> {
            String tag = (String) comboBox2.getSelectedItem();
            if(tag == null){
                //System.out.println("null");
                return;
            }else if(tag.equals("显示全部")){
                for(Shape shape :shapesALL){
                    if(!shapes.contains(shape)){
                        shapes.add(shape);
                    }
                }
            }else {
                for(Shape shape :shapes){
                    if(!shapesALL.contains(shape)){
                        shapesALL.add(shape);
                    }
                }
                while (true) {
                    int state = 0;
                    for (Shape shape : shapes) {
                        if (!shape.isTag(tag)) {
                            shapes.removeElement(shape);
                            state = 1;
                            break;
                        }
                    }
                    if (state == 0) {
                        break;
                    }
                }
            }
            Main.mainWindow.getCanvas().repaint();
            comboBox2.removeItem("显示全部");
            tagFrame.setVisible(false);
        });
        return OKButton;
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1){
            if (actTool == ARC) {
//            System.out.println(drawStatus);
                if (drawStatus == NOT_DRAWING) {
                    center = new Dimension(e.getX(), e.getY());
                    drawStatus = DEFINED_CENTER;
                } else if (drawStatus == DEFINED_CENTER) {
                    startPoint = new Dimension(e.getX(), e.getY());
                    radius = getDistance(startPoint, center);
                    benchmark = new Vec3(startPoint.width - center.width, -startPoint.height + center.height, 0);
                    drawStatus = DEFINED_R;
                    rectangle = new Rectangle(center.width - radius, center.height - radius,
                            2 * radius, 2 * radius);
                } else if (drawStatus == DEFINED_R) {
                    if (preview.size() != 0) {
                        shapes.push(preview.pop());
                        preview.clear();
                    }
                    drawStatus = NOT_DRAWING;
                    direction = NO_DIRECTION;
                }
            } else if (actTool == STRAW) {
                int x = e.getX(), y = e.getY();
                x += Main.mainWindow.getLocation().x;
                y += Main.mainWindow.getLocation().y;
                x += Main.mainWindow.getStretcher().getLocation().x;
                y += Main.mainWindow.getStretcher().getLocation().y;
                x += getLocation().x;
                y += getLocation().y;
                x += 153;
                y += 92;
                // ** ---------------- **
                try {
                    Robot robot = new Robot();
                    Color color = robot.getPixelColor(x, y);
                    System.out.println(color);
                    Main.mainWindow.setLastColor(getCurrentColor());
                    setColor(color);
                    Main.mainWindow.setCurColor(getCurrentColor());
                } catch (AWTException ex) {
                    throw new RuntimeException(ex);
                }
            } else if (actTool == DRAG) {
                for (var shape : shapes) {
                    if (shape.onPressed(x1, y1) == 1) {
                        selectedShape = shape;
                    }
                }
            }}
        else if(e.getButton() == MouseEvent.BUTTON3){
            JFrame frame = new JFrame("Right Click Menu Example");
            JPanel panel = new JPanel();
            JPopupMenu popupMenu = getRightjPopupMenu(e);
            popupMenu.show(e.getComponent(), e.getX(), e.getY());
        }
    }

    private JPopupMenu getRightjPopupMenu(MouseEvent e) {
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem copyMenuItem = new JMenuItem("复制");
        copyMenuItem.addActionListener(mr -> {
            copiedShape = selectedShape;
        });
        JMenuItem pasteMenuItem = new JMenuItem("粘贴");
        pasteMenuItem.addActionListener(mr -> {
            if(copiedShape == null){
                return;
            }
            shapes.push(new Shape(copiedShape,e.getX(),e.getY()));
            Main.mainWindow.getCanvas().repaint();
        });
        JMenuItem deleteMenuItem = new JMenuItem("删除");
        deleteMenuItem.addActionListener(mr -> {
            shapes.removeElement(selectedShape);
            Main.mainWindow.getCanvas().repaint();
        });
        JMenuItem undoMenuItem = new JMenuItem("撤销");
        undoMenuItem.addActionListener(mr -> undo());
        JMenuItem redoMenuItem = new JMenuItem("重做");
        redoMenuItem.addActionListener(mr -> redo());
        JMenuItem addLabelMenuItem = new JMenuItem("添加标签");
        addLabelMenuItem.addActionListener(mr -> {
            if(selectedShape == null){
                return;
            }
            addLabel();
        });
        JMenuItem showByLabelMenuItem = new JMenuItem("按标签显示");
        showByLabelMenuItem.addActionListener(mr -> showByLabel());
        JMenu alignmentMenu = getAlignmentMenu();
        popupMenu.add(addLabelMenuItem);
        popupMenu.add(showByLabelMenuItem);
        popupMenu.addSeparator();
        popupMenu.add(copyMenuItem);
        popupMenu.add(pasteMenuItem);
        popupMenu.add(deleteMenuItem);
        popupMenu.addSeparator();
        popupMenu.add(undoMenuItem);
        popupMenu.add(redoMenuItem);
        popupMenu.addSeparator();
        popupMenu.add(alignmentMenu);
        return popupMenu;
    }

    private JMenu getAlignmentMenu() {
        JMenu alignmentMenu = new JMenu("对齐");
        JMenuItem lift = new JMenuItem("左对齐");
        lift.addActionListener(al -> alignLeft());
        JMenuItem right = new JMenuItem("右对齐");
        right.addActionListener(al -> alignRight());
        JMenuItem top = new JMenuItem("上对齐");
        top.addActionListener(al -> alignTop());
        JMenuItem bottom = new JMenuItem("下对齐");
        bottom.addActionListener(al -> alignBottom());
        JMenuItem level = new JMenuItem("水平对齐");
        level.addActionListener(al -> alignHorizontalCenter());
        JMenuItem vertical = new JMenuItem("垂直对齐");
        vertical.addActionListener(al -> alignVerticalCenter());
        JMenuItem liftBoard = new JMenuItem("置于左端");
        liftBoard.addActionListener(al -> Left());
        JMenuItem rightBoard = new JMenuItem("置于右端");
        rightBoard.addActionListener(al -> Right());
        JMenuItem topBoard = new JMenuItem("置于上端");
        topBoard.addActionListener(al -> Top());
        JMenuItem bottomBoard = new JMenuItem("置于下端");
        bottomBoard.addActionListener(al -> Bottom());
        JMenuItem levelBoard = new JMenuItem("水平居中");
        levelBoard.addActionListener(al -> HorizontalCenter());
        JMenuItem verticalBoard = new JMenuItem("垂直居中");
        verticalBoard.addActionListener(al -> VerticalCenter());
        alignmentMenu.add(lift);
        alignmentMenu.add(right);
        alignmentMenu.add(top);
        alignmentMenu.add(bottom);
        alignmentMenu.add(level);
        alignmentMenu.add(vertical);
        alignmentMenu.addSeparator();
        alignmentMenu.add(liftBoard);
        alignmentMenu.add(rightBoard);
        alignmentMenu.add(topBoard);
        alignmentMenu.add(bottomBoard);
        alignmentMenu.add(levelBoard);
        alignmentMenu.add(verticalBoard);
        return alignmentMenu;
    }

    @Override
    public void mousePressed(MouseEvent e) {
        x1 = e.getX();
        y1 = e.getY();
        for (var shape : shapes) {
            if (shape.onPressed(x1, y1) == 1) {
                selectedShape = shape;
            }
        }
        if(actTool == ALIGNMENT){
            for (var shape : shapes) {
                shape.selected(x1,y1);
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        x2 = e.getX();
        y2 = e.getY();
        if (preview.size() != 0 && actTool != ARC) {
            shapes.push(preview.pop());
            preview.clear();
        } else if (actTool == TEXT) {
            int res = textDialog.showCustomDialog(Main.mainWindow);
            if (res == TextDialog.APPLY_OPTION) {
                shapes.push(new Shape(x1, y1, textDialog.getFont(),
                        currentColor, stroke, BasicTools.TEXT, textDialog.getText()));
                repaint();
            }
        } else if (actTool == BUCKET) {
            // todo: there needs a bucket tool.


            // -------- *** ---------
        } else if (actTool == DRAG) {
            int cx = x2 - x1;
            int cy = y2 - y1;
            if (selectedShape != null) {
//                removed.push(new Shape(selectedShape));
                selectedShape.moving(cx, cy);
//                selectedShape.draw(graphics2D, selectedShape.getColor());
//                System.out.println(selectedShape + "-> finished select");
                selectedShape.setIsChosen(0);
                selectedShape = null;
            }
        }
        if (dragged) {
            grouped++;
            dragged = false;
        }
        repaint();
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        isInCanvas = true;

        Cursor cursor = new Cursor(Cursor.CROSSHAIR_CURSOR);
        setCursor(cursor);
    }

    @Override
    public void mouseExited(MouseEvent e) {
        isInCanvas = false;
        Main.mainWindow.setMousePositionLabel(0, 0);
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        Main.mainWindow.setMousePositionLabel(e.getX(), e.getY());
        Color c1 = currentColor, c2 = lastColor;
        if (SwingUtilities.isRightMouseButton(e)) {
            c1 = c2;
            c2 = currentColor;
        }
        x2 = e.getX();
        y2 = e.getY();
        this.dragged = true;

        if (actTool == ERASER) {
            shapes.push(new Shape(x1, y1, x2, y2, Color.WHITE, stroke, LINE, grouped));
            Main.mainWindow.getCanvas().repaint();
            x1 = x2;
            y1 = y2;
        } else if (actTool == PENCIL) {
            shapes.push(new Shape(x1, y1, x2, y2, c1, stroke, LINE, grouped));
            Main.mainWindow.getCanvas().repaint();
            x1 = x2;
            y1 = y2;
        } else if (actTool == LINE) {
            preview.push(new Shape(x1, y1, x2, y2, c1, stroke, LINE, c2, isTransparent));
            Main.mainWindow.getCanvas().repaint();
        } else if (actTool == RECTANGLE) {
            pushPreview(c1, c2, RECTANGLE);
        } else if (actTool == ELLIPTICAL) {
            pushPreview(c1, c2, ELLIPTICAL);
        } else if (actTool == PENTAGON) {
            pushPreview(c1, c2, PENTAGON);
        } else if (actTool == PENTAGRAM) {
            pushPreview(c1, c2, PENTAGRAM);
        } else if (actTool == COMPASS) {
            pushPreview(c1, c2, COMPASS);
        } else if (actTool == HEXAGON) {
            pushPreview(c1, c2, HEXAGON);
        } else if (actTool == TRIANGLE) {
            pushPreview(c1, c2, TRIANGLE);
        }
    }

    private void pushPreview(Color c1, Color c2, BasicTools rectangle) {
        preview.push(new Shape(x1, y1, x2, y2, c1, stroke, rectangle, c2, isTransparent));
        Main.mainWindow.getCanvas().repaint();
    }

    public void addNewShape(Shape s) {
        shapes.push(s);
        Main.mainWindow.getCanvas().repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        Main.mainWindow.setMousePositionLabel(e.getX(), e.getY());
        if (actTool == ARC) {
            Color c1 = currentColor, c2 = lastColor;
            x2 = e.getX();
            y2 = e.getY();
            if (drawStatus == NOT_DRAWING) {
                return;
            } else if (drawStatus == DEFINED_CENTER) {
                preview.push(new Shape(x1, y1, x2, y2, c1, stroke, LINE, c1, isTransparent));
                Main.mainWindow.getCanvas().repaint();
            } else if (drawStatus == DEFINED_R) {
                //System.out.println(direction);
                if (direction == NO_DIRECTION) {
                    Vec3 temp = new Vec3(x2 - center.width, -y2 + center.height, 0);
                    direction = benchmark.calcDirection(temp);
                } else if (direction == LEFT) {
                    //System.out.println(benchmark.print());
                    int startAngle = benchmark.normalization().calcAngle(new Vec3(1, 0, 0));
                    Vec3 temp = new Vec3(x2 - center.width, -y2 + center.height, 0);
                    int drawAngle = temp.normalization().calcAngle(benchmark.normalization());
                    //System.out.println(startAngle + " " + drawAngle);
                    //System.out.println(temp.calcDirection(benchmark));
                    preview.push(new Shape(rectangle, c1, stroke, ARC, c1, isTransparent, startAngle, drawAngle));
                } else if (direction == RIGHT) {
                    int startAngle = benchmark.normalization().calcAngle(new Vec3(1, 0, 0));
                    Vec3 temp = new Vec3(x2 - center.width, -y2 + center.height, 0);
                    int drawAngle = -(360 - temp.normalization().calcAngle(benchmark.normalization()));
                    preview.push(new Shape(rectangle, c1, stroke, ARC, c1, isTransparent, startAngle, drawAngle));
                }
            }
            Main.mainWindow.getCanvas().repaint();
        }
    }

    //    public void getShapes() {
//        System.out.println(shapes);
//    }
    public void setStroke(int n) {
        this.stroke = new BasicStroke(n);
    }

    public BasicTools getActTool() {
        return this.actTool;
    }

    public Stack<Shape> getShapes() {
        for(Shape shape : shapesALL){
            if(!shapes.contains(shape)){
                shapes.add(shape);
            }
        }
        return shapes;
    }

    //左对齐
    public void alignLeft() {
        int x = 800;
        for (Shape shape : shapes){
            if(shape.isSelected == 1){
                if(shape.x1 < x){
                    x = shape.x1;
                }
            }
        }
        for (var shape : shapes){
            if(shape.isSelected == 1){
                shape.x2 = x + shape.x2 - shape.x1;
                shape.x1 = x;
            }
        }
        repaint();
    }

    //右对齐
    public void alignRight() {
        int x = 0;
        for (Shape shape : shapes){
            if(shape.isSelected == 1){
                if(shape.x2 > x){
                    x = shape.x2;
                }
            }
        }
        for (var shape : shapes){
            if(shape.isSelected == 1){
                shape.x1 = x - (shape.x2 - shape.x1);
                shape.x2 = x;
            }
        }
        repaint();
    }

    //顶端对齐
    public void alignTop() {
        int y = 800;
        for (Shape shape : shapes){
            if(shape.isSelected == 1){
                if(shape.y1 < y){
                    y = shape.y1;
                }
            }
        }
        for (var shape : shapes){
            if(shape.isSelected == 1){
                shape.y2 = y + shape.y2 - shape.y1;
                shape.y1 = y;
            }
        }
        repaint();
    }

    //底端对齐
    public void alignBottom() {
        int y = 0;
        for (Shape shape : shapes){
            if(shape.isSelected == 1){
                if(shape.y2 > y){
                    y = shape.y2;
                }
            }
        }
        for (var shape : shapes){
            if(shape.isSelected == 1){
                shape.y1 = y - (shape.y2 - shape.y1);
                shape.y2 = y;
            }
        }
        repaint();
    }

    //水平居中
    public void alignHorizontalCenter() {
        int x = 0;
        int num = 0;
        for (Shape shape : shapes){
            if(shape.isSelected == 1){
                x = x + (shape.x1 + shape.x2)/2;
                num = num + 1;
            }
        }
        for (var shape : shapes){
            if(shape.isSelected == 1){
                int cx = shape.x2 - shape.x1;
                shape.x1 = x / num - cx / 2;
                shape.x2 = x / num + cx / 2;
            }
        }
        repaint();
    }

    public void alignVerticalCenter() {
        int y = 0;
        int num = 0;
        for (Shape shape : shapes){
            if(shape.isSelected == 1){
                y = y + (shape.y1 + shape.y2)/2;
                num = num + 1;
            }
        }
        for (var shape : shapes){
            if(shape.isSelected == 1){
                int cy = shape.y2 - shape.y1;
                shape.y1 = y / num - cy / 2;
                shape.y2 = y / num + cy / 2;
            }
        }
        repaint();
    }

    public void Left() {
        int x = 0;
        for (var shape : shapes){
            if(shape.isSelected == 1){
                shape.x2 = x + shape.x2 - shape.x1;
                shape.x1 = x;
            }
        }
        repaint();
    }

    //右对齐
    public void Right() {
        int x = canvas.getWidth();
        for (var shape : shapes){
            if(shape.isSelected == 1){
                shape.x1 = x - (shape.x2 - shape.x1);
                shape.x2 = x;
            }
        }
        repaint();
    }

    //顶端对齐
    public void Top() {
        int y = 0;
        for (var shape : shapes){
            if(shape.isSelected == 1){
                shape.y2 = y + shape.y2 - shape.y1;
                shape.y1 = y;
            }
        }
        repaint();
    }

    //底端对齐
    public void Bottom() {
        int y = canvas.getHeight();
        for (var shape : shapes){
            if(shape.isSelected == 1){
                shape.y1 = y - (shape.y2 - shape.y1);
                shape.y2 = y;
            }
        }
        repaint();
    }

    //水平居中
    public void HorizontalCenter() {
        int x = canvas.getWidth()/2;
        for (var shape : shapes){
            if(shape.isSelected == 1){
                int cx = shape.x2 - shape.x1;
                shape.x1 = x  - cx / 2;
                shape.x2 = x  + cx / 2;
            }
        }
        repaint();
    }

    public void VerticalCenter() {
        int y = canvas.getHeight()/2;
        for (var shape : shapes){
            if(shape.isSelected == 1){
                int cy = shape.y2 - shape.y1;
                shape.y1 = y - cy / 2;
                shape.y2 = y  + cy / 2;
            }
        }
        repaint();
    }


    public boolean bool(int x){
        if( x == 1)  return true;
        else  return false;
    }
}
