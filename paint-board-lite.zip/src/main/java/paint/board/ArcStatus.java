package paint.board;

public enum ArcStatus {
    NOT_DRAWING,
    DEFINED_CENTER,
    DEFINED_R,
    NO_DIRECTION,
    RIGHT,
    LEFT
}