package paint.board;

public enum BasicTools {
    NULL,
    PENCIL,
    ALIGNMENT,
    ERASER,
    BUCKET,
    STRAW,
    MAGNIFYING,
    TEXT,
    LINE,
    TRIANGLE,
    ROUND,
    ELLIPTICAL,
    PENTAGON,
    HEXAGON,
    RECTANGLE,
    DRAG,
    PENTAGRAM,
    COMPASS,  ARC
}
